class Api::V1::WebhooksController < Api::V1::BaseController
    skip_before_action :verify_authenticity_token, only: [:thrivecart_checkout, :paddle_callback]
    skip_before_action :authorize_request, only: [:thrivecart_checkout, :paddle_callback]

    def thrivecart_checkout
        product = Product.find(2)
        order = Order.create(product_id: product.id, params: params, emailed: false)
        render json: { message: "Success" }, status: :ok
    end

    def paddle_callback
        customer_id = params.try(:[], "data").try(:[], "customer_id")
        if !customer_id.nil?
            user = User.find_by_paddle_customer_id(customer_id)
            user.update_paddle_subscriptions if !user.nil?
        end
        render json: { message: "Success" }, status: :ok
    end

end
