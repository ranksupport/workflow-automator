require 'will_paginate/array'
class Api::V1::KonnectsController < Api::V1::BaseController
  skip_before_action :verify_authenticity_token, only: [:webhook_receive, :webhook_complete]
  skip_before_action :authorize_request, only: [:webhook_receive, :webhook_complete]

  CONDITIONSLIST = {
    "lesser than" => "Lesser Than",
    "greater than" => "Greater Than",
    "is exist" => "Is Exist",
    "does not exist" => "Does Not Exist",
    "start with" => "Start With",
    "does not start with" => "Does Not Start With",
    "end with" => "End With",
    "does not end with" => "Does Not End With",
    "equal to" => "Equal To",
    "does not equal to" => "Does Not Equal To",
    "contain string" => "Contain String",
    "does not contain string" => "Does Not Contain String",
  }

  def conditions_list
    res = []
    CONDITIONSLIST.each do |k, v|
      res << { id: k, name: v }
    end
    res.flatten
    render json: res
  end

  def index
    per_page = params[:page_size] || 10
    search_query = "konnects.status IN ('ACTIVE','INACTIVE', 'Draft') and app_users.user_id = #{current_user.id}"
    if params[:search_query].present?
      search_query += " AND UPPER(left_apps.name) like '%#{params[:search_query].upcase}%' or UPPER(right_apps.name) like '%#{params[:search_query].upcase}%' or UPPER(konnects.name) like '%#{params[:search_query].upcase}%'"
    end
    @konnects = Konnect.where(search_query).
    joins("LEFT JOIN app_users ON konnects.app_user_id = app_users.id").
    joins("LEFT JOIN apps AS left_apps ON app_users.app_id = left_apps.id").
    joins("LEFT JOIN konnect_activities ON konnect_activities.konnect_id = konnects.id").
    joins("LEFT JOIN app_events ON konnect_activities.app_event_id = app_events.id").
    joins("LEFT JOIN apps AS right_apps ON app_events.app_id = right_apps.id").paginate(:page => params[:page_index], :per_page => per_page)

    @konnects = @konnects.order("konnects.updated_at DESC").uniq
    render json: {
      konnects: @konnects.collect { |k|
        {
          id: k.id,
          status: k.status,
          konnect_name: k.konnect_ui_information.data["konnect_name"],
          # ui_information: k.konnect_ui_information.data,
          konnect_description: k.konnect_description,
          duplicate: (k.duplicate || false),
          left_app: {
            name: (k.app_event.app.name rescue ""),
            background_color: (k.app_event.app.background_color rescue ""),
            image_url: (k.app_event.app.image_url rescue ""),
          },
          right_apps: k.display_konnect_activities.collect { |ka|
            {
              sequence_id: ka.sequence_id,
              status: ka.status,
              app_name: (ka.app_event.app.name rescue ""),
              background_color: (ka.app_event.app.background_color rescue ""),
              image_url: (ka.app_event.app.image_url rescue ""),
            }
          },
        }
      },
    }
  end

  def connect
    result = Konnect.create_konnect(params, current_user, request)
    render json: result
  end

  def webhook_complete
    if params[:challenge]
      render json: params[:challenge], status: :ok    
    elsif params["hub.challenge"]
      render json: params["hub.challenge"]  
    else
      render json: { message: "Success" }, status: :ok
    end
  end

  def webhook_receive 
    if params[:provider] == "slack" && params[:type] == "url_verification"
      render json: { challenge: params[:challenge] }, status: :ok    
    else         
      if params[:provider] == "box" || params[:provider].starts_with?("automizy")
        data = request.params
      elsif params[:provider] == "Docusign"
        res = Hash.from_xml(request.raw_post).to_json
        formatted_json = JSON.parse(res)
        data = formatted_json["DocuSignEnvelopeInformation"]["EnvelopeStatus"]["RecipientStatuses"]["RecipientStatus"]     
      elsif params[:provider].starts_with?("eventbrite")
        data = JSON.parse request.raw_post
        Rails.logger.debug "FIRST EVENTBRITE #{data.inspect}"
        webhook = Webhook.find_by(identifier: params[:provider])
        app_user = webhook.try(:app_user)
        access_token = app_user.auth_details["access_token"]
        api_url = data["api_url"]
        Rails.logger.debug "api_url.....#{api_url.inspect}"
        response = HTTParty.get(api_url,
          :headers => { 
            "Authorization" => "Bearer #{access_token}"

          }
          ).parsed_response                    
        Rails.logger.debug "#{response.inspect}"
        data.merge!(response)
        Rails.logger.debug "EVENT BRITEEE #{data.inspect}"

      elsif params[:provider].starts_with?("clio") && request.headers['HTTP_X_HOOK_SECRET'].present? 
        data = JSON.parse request.raw_post  
        Rails.logger.debug "DAT..........CLIO............#{data.inspect}"         
              
        x_hook_secret = request.headers['HTTP_X_HOOK_SECRET']        
        webhook = Webhook.find_by(identifier: params[:provider])  
        app_user = webhook.try(:app_user)  
        access_token = app_user.auth_details["access_token"]  
        webhook_id = data["data"]["webhook_id"]  
        api_url = "https://app.clio.com/api/v4/webhooks/#{webhook_id}/activate"        
        
        response = HTTParty.put(api_url,
          :headers => { 
            "Authorization" => "Bearer #{access_token}",
            "X-hook-secret" => x_hook_secret

          }
          )   
                         
        Rails.logger.debug "CLIO WEBHOOK.............#{response.inspect}"  

        #elsif params[:provider].starts_with?("convertkit")
        #data = JSON.parse request.raw_post
        #Rails.logger.debug "FIRST CONVERTKIT #{data.inspect}"
        #webhook = Webhook.find_by(identifier: params[:provider])
        #app_user = webhook.try(:app_user)
        ##access_token = app_user.auth_details["access_token"]
        ##api_secret = app_user.auth_details["api_secret"]
        #api_url = data["api_url"]
        #Rails.logger.debug "api_url.....#{api_url.inspect}"
        #response = HTTParty.post(api_url
        #  #:headers => { 
        #  #  "Authorization" => "Bearer #{access_token}"
##
 #       #  #}
 #       #  ).parsed_response                    
 #       #Rails.logger.debug "#{response.inspect}"
 #       #data.merge!(response)
        #Rails.logger.debug "CONVERTKIT #{data.inspect}"

      else
        data = JSON.parse request.raw_post
        Rails.logger.debug "RAWWWWWWWDATTTTTTTTTTTTTTTTTTTTTTT.............#{data.inspect}"
      end
      app = (webhook_params[:provider].include? "google-sheet") ? App.find_by(provider: "google_sheet") : App.find_by(provider: webhook_params[:provider])
      app_user = nil
      user = nil

      unless app
        webhook = Webhook.find_by(identifier: webhook_params[:provider])
        app_user = webhook.try(:app_user)
        app = app_user.try(:app)
        user = app_user.try(:user)
      end
      allow_webhook = true
      if(webhook_params[:provider].include? "google-sheet" and params["current_cell"]) 
        Rails.logger.debug ":::::::;999999"
        webhook = Webhook.find_by(identifier: webhook_params[:provider])
        current_konnect = webhook.konnects.last 
        indexes = ('A'..'ZZ').each_with_index.map{|l,i| [l, i+1]}.to_h
        cell = params["current_cell"].scan(/\D+/)[0] rescue "B"
        position =  params["current_cell"].scan(/\d+/)[0] rescue 1
        Rails.logger.debug ":::::::;999999 #{current_konnect.config['headers']}"

        if current_konnect && current_konnect.config['headers'] and current_konnect.config['headers']['fields']
          fields = current_konnect.config['headers']['fields']
          gs_position = "gs"+(indexes[cell]-1).to_s
          if current_konnect.config['isAnd'] and fields.include?(gs_position)
            allowed_headers = current_konnect.config['allowed_headers'][position]
            if allowed_headers
              current_konnect.config['allowed_headers'][position][gs_position] = true
            else
              current_konnect.config['allowed_headers'][position] = {"#{gs_position}" => true}
            end
            current_konnect.save!
            head =  current_konnect.config['allowed_headers'][position]
            flag = true
            fields.each_with_index {|each_gs,index|
              unless head[each_gs]
                flag = false
              end
            }
            if(flag)
              allow_webhook = true
              current_konnect.config['allowed_headers'].delete(position)
              current_konnect.save!
            else
              allow_webhook = false
            end
          elsif !current_konnect.config['isAnd'] and fields.include?(gs_position)
            allow_webhook = true
          else
            allow_webhook = false
          end
        else 
          allow_webhook = true
        end
      end
      Rails.logger.debug "web hooo {{{{{ #{allow_webhook}"
      if app && app.service_name
        service = "Services::#{app.service_name.camelcase}".constantize.new(app, user, app_user, nil, nil, webhook)
        if service.valid_signature?(request) 
          webhook_receive = WebhookReceive.create({ url: request.original_url, params: params, data: data }) if allow_webhook
          WebhookReceiveWorker.perform_async(webhook_receive.id) if allow_webhook
          render status: 200, json: {}
        else
          render status: :unauthorized, json: {}
        end
      else
        render status: :unauthorized, json: {}
      end
    end
  end

  def edit
    @konnect = Konnect.find(params[:id])
    if @konnect && @konnect.app_user.user_id == current_user.id
      canvas_json = @konnect.konnect_ui_information.data
      render json: { 
        id: @konnect.id, 
        duplicate: (@konnect.duplicate || false), 
        canvas_json: canvas_json,
        activity_dates: @konnect.konnect_activities.collect { |ka|
          {
            konnect_activity_id: ka.id,
            created_at: ka.created_at
          }
        }
      }
    else
      render json: { error: "Couldn't find Konnect with 'id'=#{params[:id]}" }
    end
  end

  def update_status
    @konnect = Konnect.find(params[:id])
    if @konnect
      konnect_activities = @konnect.konnect_activities 
      test_failed = false
      konnect_activities.each do |k_a|
        if k_a.app_event.app.app_type != "ADD_ON"
          test_failed = true if (!KonnectActivityTest.exists?(konnect_activity_id: k_a.id) or KonnectActivityTest.where(konnect_activity_id: k_a.id).last.status == "Failure")
        end
      end
      left_konnect_activity_test = KonnectActivityTest.where(konnect_id: params[:id], konnect_activity_id: nil).last
      if params[:status] == 'ACTIVE'
        if konnect_activities.count == 0 or (left_konnect_activity_test and left_konnect_activity_test.status == "Failure")
          render json: { message: "FAILED"}
        elsif konnect_activities.count > 0 and test_failed
          render json: { message: "FAILED"}
        elsif konnect_activities.count > 0 and !test_failed and left_konnect_activity_test.status == "Success"
          if @konnect.enable_webhook and @konnect.update(status: "ACTIVE")
            render json: { message: "SUCCESS"}
          else
            render json: { message: "FAILED"}
          end
        end
      elsif params[:status] != 'ACTIVE' && @konnect.app_user.user_id == current_user.id && @konnect.update_attribute(:status, params[:status])
        render json: { message: "SUCCESS" }, status: :ok
      else
        render json: { message: "FAILED" }
      end
    else
      render json: { message: "FAILED" }
    end
  end

  def update_konnect
    @konnect = Konnect.find(params[:id])
    if @konnect && @konnect.app_user.user_id == current_user.id && @konnect.update_attribute(:status, "DELETED")
      result = Konnect.create_konnect(params, current_user, request)
      render json: result
    else
      render json: { message: "FAILED" }
    end
  end

  def left_app_trigger_test_event(params)
    konnect, left_app_event = Konnect.create_or_update_left_app_konnect(params, current_user, request)
    if konnect.present?
      app = konnect.app_event.app
      app_user = konnect.app_user
      service = "Services::#{app.service_name.camelcase}".constantize.new(app, current_user, app_user, konnect)
      parsed_error_response, raw_response, test_status = service.fetch_recent_response(params)

      config_values = left_app_event.fetch_config_values(raw_response, test_status, "left")
      res = {
        konnect_id: konnect.id,
        konnect_activity_id: 0,
        config_fields: (test_status == "Success" ? config_values : konnect.config),
        test_status: test_status,
      }
      res["konnect_custom"] = konnect.config if app.service_name == "google_form" || app.service_name == "google_sheet"
      res.merge!({ errors: parsed_error_response }) if parsed_error_response.present?
      res.merge!({ raw_response: raw_response })
      res.merge!(test_status == "Success" ? { display_message: "Success: #{left_app_event.name.to_s} on #{app.name.to_s}" } : { display_message: "Failed: #{left_app_event.name.to_s} on #{app.name.to_s}" })
      k = KonnectActivityTest.new(konnect_id: konnect.id)
      k.data = raw_response
      k.status = test_status
      k.save
      render json: res
    end
  end

  def save_konnect
    begin
      konnect_ui = KonnectUiInformation.find_by(konnect_id: params[:konnect_id])
      if konnect_ui.present?
        konnect_ui.update(data: params[:canvas_json])
        konnect_ui.konnect.update(name: params[:canvas_json][:konnect_name])
      else
        KonnectUiInformation.create({ konnect_id: params[:konnect_id], data: params[:canvas_json] })
      end
      render json: { message: "Konnect Saved Successfully!" }
    rescue Exception => e
      render json: { message: "Save konnect failed" }
    end
  end

  def publish_konnect
    begin
      konnect = Konnect.find_by(id: params[:konnect_id])
      if konnect.present?
        konnect_ui = KonnectUiInformation.find_or_create_by(konnect_id: params[:konnect_id])
        konnect_ui.update(data: params[:canvas_json]) if !params[:canvas_json].nil?
        konnect_activities = konnect.konnect_activities
        test_failed = false
        konnect_activities.each do |k_a|
          if k_a.app_event.app.app_type != "ADD_ON" and KonnectActivityTest.where(konnect_activity_id: k_a.id).last.status == "Failure"
            test_failed = true
          end
        end
        left_konnect_activity_test = KonnectActivityTest.where(konnect_id: params[:konnect_id], konnect_activity_id: nil).last
        if konnect_activities.count == 0 or (left_konnect_activity_test and left_konnect_activity_test.status == "Failure")
          render json: { message: "Couldn't publish konnect, no actions configured!", publish_status: "Failure" }
        elsif konnect_activities.count > 0 and test_failed
          render json: { message: "Couldn't publish konnect, configuration incomplete!", publish_status: "Failure" }
        elsif konnect_activities.count > 0 and !test_failed and left_konnect_activity_test.status == "Success"
          if konnect.enable_webhook and konnect.update(status: "ACTIVE")
            konnect.update(duplicate: false) if konnect.duplicate == true
            render json: { message: "Konnect published successfully!", publish_status: "Success" }
          else
            render json: { message: "Failed to publish konnect, please contact support", publish_status: "Failure" }
          end
        end
      end
    rescue Exception => e
      render json: { message: "Publishing Konnect failed", publish_status: "Failure" }
    end
  end

  def test_and_review
    if params[:left_app_id].present?
      left_app_trigger_test_event(params)
    else
      begin
        konnect = Konnect.find(params[:konnect_id])
        raw_response = konnect.create_right_app_activity(params, current_user)
        render json: raw_response
      rescue Exception => e
        render json: {
         konnect_id: params[:konnect_id],
         konnect_activity_id: params[:konnect_activity_id],
         config_fields: params[:config],
         raw_response: {},
         error: e.message,
         errors: [],
         test_status: "Failure",
       }
     end
   end
  end

  def delete_activity
    konnect_ui = KonnectUiInformation.find_by(konnect_id: params[:konnect_id])
    if konnect_ui.present?
      konnect_ui.update(data: params[:canvas_json])
    else
      KonnectUiInformation.create({ konnect_id: params[:konnect_id], data: params[:canvas_json] })
    end
    begin
      @konnect = Konnect.find(params[:konnect_id])
      if params[:konnect_activity_id] and params[:konnect_activity_id] == 0
        KonnectActivityTest.delete(konnect_id: params[:konnect_id]) if KonnectActivityTest.exists?(konnect_id: params[:konnect_id])
        KonnectUiInformation.delete(konnect_id: params[:konnect_id]) if KonnectUiInformation.exists?(konnect_id: params[:konnect_id])
        KonnectWebhook.delete(konnect_id: params[:konnect_id]) if KonnectWebhook.exists?(konnect_id: params[:konnect_id])
        @konnect.soft_delete = true
        @konnect.update(status: "DELETED")
      elsif params[:konnect_activity_id] and params[:konnect_activity_id] > 0
        activity = @konnect.konnect_activities.find(params[:konnect_activity_id]) if KonnectActivity.exists?(params[:konnect_activity_id])
        KonnectActivityTest.delete(konnect_activity_id: activity.id) if activity and KonnectActivityTest.exists?(konnect_activity_id: activity.id)
        activity.destroy if activity
      end
      render json: { message: "Konnect activity removed successfully!" }
    rescue Exception => e
      render json: { message: "Failed to remove konnect activity." }
    end
  end

  def place_webhook_activity
    current_user = User.first
    konnect = Konnect.find(params[:id])
    if konnect.present?
      app = konnect.app_event.app
      app_user = konnect.app_user

      @service = "Services::#{app.service_name.camelcase}".constantize.new(app, current_user, app_user, nil)
      if @service
        res = @service.place_webhook_activity(konnect)
        render json: res
      else
        render json: { error: "Service not found" }
      end
    end
  end

  def duplicate
    konnect = Konnect.find(params[:id])
    konnect_ui = konnect.konnect_ui_information
    if konnect and konnect_ui
      new_konnect = Konnect.create(app_user_id: konnect.app_user_id, app_event_id: konnect.app_event_id, status: 'Draft', config: konnect.config, webhook_enabled: konnect.webhook_enabled, folder_id: konnect.folder_id, duplicate: true, parent_konnect_id: konnect.id)
      new_konnect_ui = KonnectUiInformation.new(konnect_id: new_konnect.id, data: konnect_ui.data)
      if new_konnect_ui.save
        render json: { message: "Duplicate created successfully!", status: 'SUCCESS' }
      else
        render json: { message: "Failed to duplicate!", status: 'FAILED' }
      end
    end
  end

  private

  def webhook_params
    params.permit!
  end
end
