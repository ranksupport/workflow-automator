class Api::V1::AppsController < Api::V1::BaseController

    skip_before_action :authorize_request, only: [:public_app_list, :public_events]

    # GET /api/v1/apps
    def index
        per_page = params[:page_size] || 30
        query = ''
        webhook_url = App.generate_webhook_url(current_user)
        if params[:search_query].present?
            query += "AND UPPER(apps.name) like '%#{params[:search_query].upcase}%'"
        end
        if params[:category].present?
            query += "AND category_tags like '%#{params[:category]}%'"
        end
        @most_used_apps = []
        @most_used_apps = App.find(AppUser.group(:app_id).select(:app_id)[0..10].map{|a| a.app_id}-[11]) if !params[:search_query].present?
        @apps = App.where("app_type != 'ADD_ON' #{query}").paginate(:page => params[:page_index], :per_page => per_page)
        @all_apps = query.empty? ? (@most_used_apps+@apps).uniq : @apps.uniq
        render json: {
            label: "Apps",
            apps: @all_apps.collect{|a|
                {
                    id: a.id,
                    name: a.name,
                    auth_type: a.auth_type,
                    side: a.side,
                    background_color: a.background_color,
                    image_url: a.image_url,
                    provider: a.provider,
                    account_count: a.app_users.where("app_users.user_id = ?", current_user.id).count,
                    status: a.status,
                    webhook_enabled: a.webhook_enabled,
                    webhook_instructions: a.webhook_instructions,
                    app_type: a.app_type,
                    webhook_url: ['WEBHOOK', 'WEBHOOK_API'].include?(a.app_type) ? webhook_url : ""
                }
            }
        }
    end

    # GET /api/v1/apps/add_on_apps
    def add_on_apps
        # @add_on_apps = App.where("app_type = 'ADD_ON'")
        @add_on_apps = App.where("app_type = 'ADD_ON' AND UPPER(name) != 'DELAY'")
        render json: {
            label: "Add-On Apps",
            apps: @add_on_apps.collect{|a|
                {
                    id: a.id,
                    name: a.name,
                    auth_type: a.auth_type,
                    side: a.side,
                    background_color: a.background_color,
                    image_url: a.image_url,
                    provider: a.provider,
                    status: a.status,
                    app_type: a.app_type
                }
            }
        }
    end

    def authorized_apps1
        @apps = params[:search_query].nil? ? current_user.apps.uniq : current_user.apps.where("UPPER(apps.name) like '%#{params[:search_query].upcase}%'").uniq
        @webhook_enabled_apps = params[:search_query].nil? ? App.where("app_type ='WEBHOOK'") : App.where("app_type = 'WEBHOOK' AND UPPER(apps.name) like '%#{params[:search_query].upcase}%'")
        @add_ons = App.where(app_type: 'ADD_ON')
        webhook_url = App.generate_webhook_url(current_user)
        render json:
        [
            [
                label: "Most Used",
                apps: (@apps[0..5]+@webhook_enabled_apps[0..5]).uniq.collect{|a|
                    {
                        id: a.id,
                        name: a.name,
                        auth_type: a.auth_type,
                        side: a.side,
                        background_color: a.background_color,
                        image_url: a.image_url,
                        provider: a.provider,
                        account_count: a.app_users.where("app_users.user_id = ?", current_user.id).count,
                        webhook_enabled: a.webhook_enabled,
                        webhook_instructions: a.webhook_instructions,
                        webhook_url: ['WEBHOOK', 'WEBHOOK_API'].include?(a.app_type) ? webhook_url : "",
                        status: a.status,
                        app_type: a.app_type
                    }
                }
            ],
            [
                label: "Authorised Apps",
                apps: @apps.select {|app| ['API','WEBHOOK_API'].include?(app.app_type)}.uniq.collect{|a|
                    {
                        id: a.id,
                        name: a.name,
                        auth_type: a.auth_type,
                        side: a.side,
                        background_color: a.background_color,
                        image_url: a.image_url,
                        provider: a.provider,
                        account_count: a.app_users.where("app_users.user_id = ?", current_user.id).count,
                        webhook_url: a.app_type == 'WEBHOOK_API' ? webhook_url : "",
                        webhook_enabled: a.webhook_enabled,
                        webhook_instructions: a.webhook_instructions,
                        status: a.status,
                        app_type: a.app_type
                    }
                }
            ],
            [
                label: "Webhook Apps",
                apps: @webhook_enabled_apps.collect{|a|
                    {
                        id: a.id,
                        name: a.name,
                        auth_type: a.auth_type,
                        side: a.side,
                        background_color: a.background_color,
                        image_url: a.image_url,
                        provider: a.provider,
                        status: a.status,
                        webhook_enabled: a.webhook_enabled,
                        webhook_instructions: a.webhook_instructions,
                        app_type: a.app_type,
                        webhook_url: webhook_url
                    }
                }
            ],
            [
                label: "Add-On Apps",
                apps: @add_ons.collect{|a|
                    {
                        id: a.id,
                        name: a.name,
                        auth_type: a.auth_type,
                        side: a.side,
                        background_color: a.background_color,
                        image_url: a.image_url,
                        provider: a.provider,
                        status: a.status,
                        app_type: a.app_type
                    }
                }
            ]
        ]
    end

    # GET /api/v1/apps/:app_id/authorized_apps
    def authorized_app_accounts
        @app = App.find(params[:id])
        @auth_accounts = @app.app_users.where("app_users.user_id = ?", current_user.id)
        render json: {
            authorized_app_accounts: @auth_accounts.collect{|a|
                {
                    id: a.id,
                    name: a.label.nil? ? a.app.name.to_s+' Account #'+(@auth_accounts.index(a).to_i+1).to_s : a.label.to_s,
                    created_at: a.created_at,
                    status: a.status
                }
            }
        }
    end


    def public_app_list
        query = "app_type != 'ADD_ON'"
        if params[:search_query].present?
            query += " AND UPPER(apps.name) like '%#{params[:search_query].upcase}%'"
        end
        @all_apps = App.where(query).uniq
        render json: {
            apps: @all_apps.collect{|a|
                {
                    id: a.id,
                    name: a.name,
                    description: a.description,
                    side: a.side,
                    identifier: a.name.split(" ").join('-'),
                    background_color: a.background_color,
                    image_url: a.image_url
                }
            }
        }
    end

    def public_events
        name = params[:app_identifier].split("-").join(" ")
        @app = App.where(name: name).first
        if @app.nil?
            render json: {
                message: "Couldn't find the app!"
            }
        else
            @triggers = @app.app_events.where("side = 'left' and name != 'webhook_trigger'")
            @actions = @app.app_events.where(side: 'right')
            render json: {
                id: @app.id,
                name: @app.name,
                description: @app.description,
                side: @app.side,
                identifier: @app.name.split(" ").join('-'),
                background_color: @app.background_color,
                image_url: @app.image_url,
                triggers: @triggers.collect{|a|
                    {
                        name: a.name,
                        description: a.description
                    }
                },
                actions: @actions.collect{|a|
                    {
                        name: a.name,
                        description: a.description
                    }
                }
            }
        end
    end

    def get_triggers
    webhook_url = App.generate_webhook_url(current_user)
    @triggers = App.where("side != 'Right'")
    Rails.logger.debug "GET_TRIGGERS #{@triggers}"
    render json: {
             label: "Triggers",
             apps: @triggers.collect { |a|
               {
                 id: a.id,
                 name: a.name,
                 auth_type: a.auth_type,
                 side: a.side,
                 background_color: a.background_color,
                 image_url: a.image_url,
                 provider: a.provider,
                 account_count: a.app_users.where("app_users.user_id = ?", current_user.id).count,
                 status: a.status,
                 webhook_enabled: a.webhook_enabled,
                 webhook_instructions: a.webhook_instructions,
                 app_type: a.app_type,
                 webhook_url: ["WEBHOOK", "WEBHOOK_API"].include?(a.app_type) ? webhook_url : "",
               }
             },
           }
  end

  def get_allapps
    webhook_url = App.generate_webhook_url(current_user)
    @apps = App.where("app_type != 'ADD_ON'")
    Rails.logger.debug "GET_ALL_APPS #{@apps}"
    render json: {
             label: "All Apps",
             apps: @apps.collect { |a|
               {
                 id: a.id,
                 name: a.name,
                 auth_type: a.auth_type,
                 side: a.side,
                 background_color: a.background_color,
                 image_url: a.image_url,
                 provider: a.provider,
                 account_count: a.app_users.where("app_users.user_id = ?", current_user.id).count,
                 status: a.status,
                 webhook_enabled: a.webhook_enabled,
                 webhook_instructions: a.webhook_instructions,
                 app_type: a.app_type,
                 webhook_url: ["WEBHOOK", "WEBHOOK_API"].include?(a.app_type) ? webhook_url : "",
               }
             },
           }
  end

  def get_actions
    webhook_url = App.generate_webhook_url(current_user)
    @actions_app = App.where("side != 'Left'")
    Rails.logger.debug "GET_ACTIONS #{@actions_app}"
    render json: {
             label: "Actions",
             apps: @actions_app.collect { |a|
               {
                 id: a.id,
                 name: a.name,
                 auth_type: a.auth_type,
                 side: a.side,
                 background_color: a.background_color,
                 image_url: a.image_url,
                 provider: a.provider,
                 account_count: a.app_users.where("app_users.user_id = ?", current_user.id).count,
                 status: a.status,
                 webhook_enabled: a.webhook_enabled,
                 webhook_instructions: a.webhook_instructions,
                 app_type: a.app_type,
                 webhook_url: ["WEBHOOK", "WEBHOOK_API"].include?(a.app_type) ? webhook_url : "",
               }
             },
           }
  end

end
