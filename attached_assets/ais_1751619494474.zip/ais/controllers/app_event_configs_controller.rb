class Api::V1::AppEventConfigsController < Api::V1::BaseController

    before_action :check_config

    #GET /api/v1/apps/:app_id/app_events/:app_event_id/config/:side
    def event_config
        @configs = @app_event.app_event_configs.where(side: params[:side])
        res = @configs.collect do |config|
            {
                id: config.sequence == 0 ? config.config_key : config.id,
                app_id: config.app_id,
                app_event_id: config.app_event_id,
                config_key: config.config_key,
                config_key_required: config.config_key_required,
                label: config.label,
                side: config.side,
                key_value_type: config.key_value_type,
                fetch_fields: config.fetch_fields,
                sequence: config.sequence
            }
        end
        render json: res.to_json
    end

    #GET /api/v1/apps/:app_id/app_events/:app_event_id/config/:side/:sequence/details
    def event_config_details
        @config = @app_event.app_event_configs.where(side: params[:side], id: params[:config_id]).first
        if @config
            @app_user = (!params[:app_account_id].nil? ? AppUser.find(params[:app_account_id]) : current_user.app_users.find_by(app_id: @app.id))
            fetch = Services::Fetch.new(@app_user, @config, params)
            res = fetch.request
            render json: res.to_json
        else
            render json: {error: "Config sequence is not found."}
        end
    end

    def fetch_fields
        current_user = User.first
        @app_user = (!params[:app_account_id].nil? ? AppUser.find(params[:app_account_id]) : AppUser.where(app: @app, user: current_user).first)
        @service = "Services::#{@app.service_name.camelcase}".constantize.new(@app, current_user, @app_user, nil)
        if @service
            res = @service.fetch_fields(params)
            render json: res
        else
            render json: {error: "Service not found"}
        end
    end

    private

    def check_config
        @app = App.find_by(id: params[:app_id])
        if @app
            @app_event = @app.app_events.find_by(id: params[:app_event_id])
            render json: {error: "App event id is not valid."} unless @app_event
            render json: {error: "App event side is not correct. Valid values are left or right."} unless params[:side] == 'left' || params[:side] == 'right'
        else
            render json: {error: "App id is not valid."}
        end
    end
end