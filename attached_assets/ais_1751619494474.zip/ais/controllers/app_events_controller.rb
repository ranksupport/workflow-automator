class Api::V1::AppEventsController < Api::V1::BaseController

    before_action :set_app

    #GET /api/v1/apps/:app_id/app_events
    def index
        if @app
            @app_events = @app.app_events.where("name != 'webhook_trigger'")
            render json: @app_events.to_json
        else
            render json: {error: "App id is not valid."}
        end
    end

    private

    def set_app
        @app = App.find_by(id: params[:app_id])
    end
end