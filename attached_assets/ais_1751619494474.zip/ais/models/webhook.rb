class Webhook < ApplicationRecord
    belongs_to :app_user
    belongs_to :app_event, optional: true
    belongs_to :webhook_status, optional: true
    has_many :konnects

    after_initialize :set_identifier

    def remove_webhook
        begin

            result = konnects.all? {|k| (k.status == "DELETED" || k.status == "INACTIVE")}
            if result
                service = "Services::#{app_user.app.service_name.camelcase}".constantize.new(app_user.app, app_user.user, app_user, nil, nil, self)
                service.remove_webhook
            end
        rescue Exception => e
            Rails.logger.info e
        end
    end
    private

    def set_identifier
	    app = app_user.try(:app)
        self.identifier = self.class.generate_identifier(app) if app && self.new_record? && self.identifier.nil?
    end

    def self.generate_identifier(app)
        app.name.downcase.gsub(' ', '-') + '-' + SecureRandom.hex(20)
    end

end
