# == Schema Information
#
# Table name: konnects
#
#  id           :bigint           not null, primary key
#  app_user_id  :integer          not null
#  app_event_id :integer          not null
#  status       :boolean          default(TRUE)
#  created_at   :datetime         not null
#  updated_at   :datetime         not null
#  config       :json
#
# Konnect Status ACTIVE | INACTIVE | ARCHIVED | DELETED

class Konnect < ApplicationRecord
  belongs_to :app_user
  belongs_to :app_event
  has_many :konnect_activities, dependent: :destroy
  has_many :webhook_statuses, as: :webhookable
  has_one :konnect_ui_information
  has_one :konnect_webhook
  belongs_to :webhook, optional: true
  has_many :tasks
  has_many :task_logs
  has_many :webhook_receive_activities
  has_many :konnect_activity_tests
  belongs_to :folder, optional: true

  after_save :delete_webhook
  attr_accessor :soft_delete

  scope :active_konnects, -> { where(status: "ACTIVE") }

  def self.create_or_update_left_app_konnect(params, user, request)
    left_app = nil
    left_app_user = nil
    left_app_event = nil
    konnect = nil
    konnect_activity = nil
    konnect_activities = []
    konnect_webhook = nil

    begin
      raise "User is not present" unless user

      left_app = App.find_by(id: params[:left_app_id])
      if left_app
        if !["WEBHOOK", "ADD_ON", "WEBHOOK_API"].include?(left_app.app_type)
          left_app_user = (params[:app_account_id].nil? ? AppUser.where(user: user, app: left_app).first : AppUser.find(params[:app_account_id]))
        elsif ["Scheduler", "RSS"].include?(left_app.name)
          left_app_user = (params[:app_account_id].nil? ? AppUser.find_or_create_by(user: user, app: left_app) : AppUser.find(params[:app_account_id]))
        end
      else
        raise "Left side app id is not valid."
      end
      Rails.logger.debug "RSS_FEED_0 <><> #{params}"
      left_app_event = left_app.app_events.find_by(id: params[:left_app_event_id]) if !["WEBHOOK", "ADD_ON", "WEBHOOK_API"].include?(left_app.app_type) or left_app.name == "Scheduler"

      if left_app_event
        konnect = params[:konnect_id].present? ? Konnect.find_by(id: params[:konnect_id]) : Konnect.new
        konnect.app_event = left_app_event
        konnect.app_user = left_app_user
        konnect.config = params[:left_config]
        konnect.config = konnect.config.merge({ "trigger_time": DateTime.now.in_time_zone(KNZT_TIMEZONE[user.timezone]).strftime("%Y-%m-%d %H:%M") }) if left_app.name == "Scheduler"
        konnect.status = "Draft"
        konnect.name = params[:canvas_json][:konnect_name]
        konnect.save!
        unless konnect.valid?
          raise "Something went wrong while creating konnect."
        end
      elsif left_app.app_type == "WEBHOOK" or left_app.app_type == "WEBHOOK_API"
        if !params[:left_app_event_id].nil?
          left_app_event = left_app.app_events.find_by(id: params[:left_app_event_id])
        else
          left_app_event = AppEvent.find_or_create_by(name: "webhook_trigger", app_id: left_app.id, side: "left")
        end
        identifier = params[:webhookUrl].split("/").last
        konnect_webhook = KonnectWebhook.find_or_create_by(identifier: identifier)

        left_app_user = AppUser.find_or_create_by(app_id: left_app.id, user_id: user.id)
        konnect = Konnect.find_by(id: params[:konnect_id]) if params[:konnect_id].present?
        if konnect.nil? and !konnect_webhook.konnect_id.nil?
          konnect = Konnect.find_by(id: konnect_webhook.konnect_id)
        end
        konnect = Konnect.new if konnect.nil?
        konnect.app_event = left_app_event
        konnect.app_user = left_app_user
        konnect.config = params[:left_config]
        konnect.status = "Draft"
        konnect.webhook_enabled = true
        konnect.name = params[:canvas_json][:konnect_name]
        konnect.save!

        unless konnect.valid? && konnect_webhook.update(konnect: konnect)
          raise "Something went wrong while creating konnect."
        end
      elsif left_app.app_type == "ADD_ON" and left_app.name != "Scheduler"
        left_app_event = left_app.app_events.find_by(id: params[:left_app_event_id])
        left_app_user = AppUser.find_or_create_by(app_id: left_app.id, user_id: user.id)
        konnect = Konnect.find_by(id: params[:konnect_id]) if params[:konnect_id].present?

        konnect = Konnect.new if konnect.nil?
        konnect.app_event = left_app_event
        konnect.app_user = left_app_user
        konnect.config = params[:left_config]
        konnect.status = "Draft"
        konnect.name = params[:canvas_json][:konnect_name]
        konnect.save!

        unless konnect.valid?
          raise "Something went wrong while creating konnect."
        end
      else
        raise "Left side app event is not valid."
      end
      konnet_ui = KonnectUiInformation.find_or_create_by(konnect: konnect)
      konnet_ui.update(data: params[:canvas_json])
    rescue Exception => e
      konnect_webhook.destroy if konnect.try(:konnect_webhook).present?
      konnect.destroy if konnect.try(:id).present?
      konnet_ui.destroy if konnect.try(:konnect_ui_information).present?
      return { error: e.message }
    end
    Rails.logger.debug "RSS_FEED_1"
    [konnect, left_app_event]
  end

  def create_right_app_activity(params, current_user)
    right_app = App.find(params[:app_id])
    konnet_ui = KonnectUiInformation.find_or_create_by(konnect: self)
    konnet_ui.update(data: params[:canvas_json])
    konnet_ui.konnect.update(name: params[:canvas_json][:konnect_name])
    condition_app = false
    api_app = false
    api_app = (right_app and right_app.app_type == "ADD_ON" and right_app.name.downcase == "api") ? true : false
    coupon_app = (right_app and right_app.app_type == "ADD_ON" and right_app.provider.downcase == "generator") ? true : false
    if right_app
      app_user = (params[:app_account_id].nil? ? AppUser.where(app: right_app, user: current_user).first : AppUser.find(params[:app_account_id]))
      if params[:app_event_id].nil? or (right_app and right_app.app_type == "ADD_ON" and right_app.name == "Condition")
        right_app_event = App.where(name: "Condition").first.app_events.first
        condition_app = true
      else
        right_app_event = right_app.app_events.find(params[:app_event_id])
      end
      if right_app_event and !condition_app
        Rails.logger.debug "<DELAY_CONFIG_0>  #{params}"
        if !params[:delay_config].blank? and !params[:delay_config].try(:[], :delay_type).blank?
          Rails.logger.debug "<DELAY_CONFIG_1> "
          if !params[:delay_activity_id].nil?
            delay_activity = self.konnect_activities.find(params[:delay_activity_id])
            delay_activity.update(config: params[:delay_config])
          else
            delay_app = App.where(name: "Delay").first
            delay_app_event = delay_app.app_events.first
            delay_activity = self.konnect_activities.create({
              app_event: delay_app_event,
              config: params[:delay_config],
            })
          end
        end
        if !params[:konnect_activity_id].nil? and params[:konnect_activity_id] > 0
          activity = self.konnect_activities.find(params[:konnect_activity_id])
          activity.update(app_event: right_app_event, app_user: app_user, config: params[:config])
        else
          activity = self.konnect_activities.create({
            app_event: right_app_event,
            app_user: app_user,
            config: params[:config],
          })
        end
        if activity
          begin
            data = KonnectActivityTest.where(konnect_id: params[:konnect_id], konnect_activity_id: nil).last.data
            Rails.logger.debug "<TRIGGER_DATA (create_right_app_activity)>  #{data}"
            service = "Services::#{right_app.service_name.camelcase}".constantize.new(right_app, current_user, app_user, self, activity)
            add_on_app = (right_app.app_type == "ADD_ON")
            response = service.test_and_review(activity, data, add_on_app)

            config_values = {}
            if !add_on_app or coupon_app
              config_values = right_app_event.fetch_config_values(response[0], response[1], "right")
              parsed_errors, generic_error = service.fetch_config_errors(response[0], right_app_event)
              # pass_through_condition = {'pass_through_condition': params[:config][:pass_through_condition], 'condition_activity_id': params[:config][:condition_activity_id]}
              # config_values = JSON.parse(config_values)
              # config_values = config_values.merge(pass_through_condition)
            elsif add_on_app and right_app.name == "API"
              if response[1] == "Failure"
                generic_error = true
                parsed_errors = { :message => response[0] }
              end
            end
            Rails.logger.debug "<RESPONSE_FROM_SERVICE (create_right_app_activity)>  #{response} <><> #{generic_error} <><> #{parsed_errors}"
            res = {
              konnect_id: params[:konnect_id],
              konnect_activity_id: activity.id,
              config_fields: (response[1] == "Success" ? config_values : params[:config]),
              raw_response: (response[1] == "Success" ? response[0] : {}),
              errors: (response[1] != "Success" ? parsed_errors : {}),
              test_status: response[1],
              pass_through_condition: params[:config][:pass_through_condition],
              condition_activity_id: params[:config][:condition_activity_id],
              delay_config: params[:delay_config],
              delay_activity_id: !delay_activity.nil? ? delay_activity.id : "",
            }
            res.merge!(response[1] == "Success" ? { display_message: "Data sent to #{right_app.name.to_s}" } : { display_message: (generic_error ? "Error: " + parsed_errors[:message] : "Failed to send data to #{right_app.name.to_s}") })
            return res
          rescue Exception => e
            Rails.logger.debug "<KONNECT_ERROR_MANAGE_0>"
            res = {
              konnect_id: params[:konnect_id],
              konnect_activity_id: activity.try(:id),
              config_fields: params[:config],
              raw_response: {},
              errors: parsed_errors.try,
              test_status: "Failure",
              display_message: "Failed to send data to #{right_app.try(:name).to_s}",
              pass_through_condition: params[:config][:pass_through_condition],
              condition_activity_id: params[:config][:condition_activity_id],
              delay_config: params[:delay_config],
              delay_activity_id: !delay_activity.nil? ? delay_activity.id : "",
            }
          end
        else
          raise "Error while creating konnect to #{right_app.name}"
        end
      elsif condition_app
        if !params[:konnect_activity_id].nil? and params[:konnect_activity_id] > 0
          activity = self.konnect_activities.find(params[:konnect_activity_id])
          activity.update(app_event: right_app_event, app_user: nil, config: params[:config])
        else
          activity = self.konnect_activities.create({
            app_event: right_app_event,
            app_user: nil,
            config: params[:config],
          })
          konnect_activity_test = KonnectActivityTest.find_or_create_by(konnect: self, konnect_activity: activity)
          test_data = KonnectActivityTest.where(konnect: self, konnect_activity_id: (params[:config].first["attribute"]["konnect_activity_id"] > 0 ? params[:config].first["attribute"]["konnect_activity_id"] : nil)).try(:last)
          data = test_data.try(:data).merge({ "parse_condition_status" => true })
          konnect_activity_test.data = data
          konnect_activity_test.status = "Success"
          konnect_activity_test.save
        end
        res = {
          konnect_id: params[:konnect_id],
          konnect_activity_id: activity.try(:id),
          config_fields: params[:config],
          raw_response: {},
          errors: {},
          test_status: "Success",
          display_message: "Success: Data sent to #{right_app.try(:name).to_s}",
        }
      else
        raise "Right side app #{right_app.name} event is not valid."
      end
    else
      raise "Right side app id is not valid."
    end
  end

  # def self.create_konnect(params, user, request)
  #       left_app = nil
  #       left_app_user = nil
  #       left_app_event = nil
  #   konnect = nil
  #   konnect_activity = nil
  #   right_app = nil
  #   right_app_user = nil
  #   right_app_event = nil
  #   konnect_activities = []
  #   konnect_webhook = nil

  #   begin
  #     raise "User is not present" unless user

  #     left_app = App.find_by(id: params[:left_app_id])
  #     if left_app
  #       left_app_user = AppUser.where(user: user, app: left_app).first if !['WEBHOOK', 'ADD_ON'].include?(left_app.app_type)
  #     else
  #       raise "Left side app id is not valid."
  #     end

  #     left_app_event = left_app.app_events.find_by(id: params[:left_app_event_id]) if !['WEBHOOK', 'ADD_ON'].include?(left_app.app_type)
  #     if left_app_event
  #       konnect = Konnect.create({
  #         app_event:      left_app_event,
  #         app_user:       left_app_user,
  #         config:         params[:left_config],
  #         status:         'ACTIVE'
  #       })
  #       unless konnect.valid?
  #         raise "Something went wrong while creating konnect."
  #       end
  #     elsif left_app.app_type == 'WEBHOOK'
  #       if !params[:left_app_event_id].nil?
  #         left_app_event = left_app.app_events.find_by(id: params[:left_app_event_id])
  #       else
  #         left_app_event = AppEvent.find_or_create_by(name: 'webhook_trigger', app_id: left_app.id, side: 'left')
  #       end
  #       left_app_user = AppUser.find_or_create_by(app_id: left_app.id, user_id: user.id)
  #       konnect = Konnect.create({
  #         app_event:      left_app_event,
  #         app_user:       left_app_user,
  #         config:         params[:left_config],
  #         status:         'ACTIVE',
  #         webhook_enabled: true
  #       })
  #       identifier = params[:webhookUrl].split('/').last
  #       konnect_webhook = KonnectWebhook.find_by(identifier: identifier)
  #       unless konnect.valid? && konnect_webhook.update(konnect: konnect)
  #         raise "Something went wrong while creating konnect."
  #       end
  #     else
  #       raise "Left side app event is not valid."
  #     end

  #     right_apps = params["right_apps"]
  #     if right_apps && right_apps.kind_of?(Array) && right_apps.count > 0
  #       sequence = 1
  #       right_apps.each do |app_config|
  #         app = App.find_by(id: app_config[:app_id])
  #         if app
  #           app_user = AppUser.where(user: user, app: app).first
  #         else
  #           raise "Right side app id is not valid."
  #         end

  #         app_event = app.app_events.find_by(id: app_config[:app_event_id])
  #         if app_event
  #           konnect_activity = KonnectActivity.create({
  #             app_event:              app_event,
  #             app_user:               app_user,
  #             konnect:                konnect,
  #             left_app_id:            app_config[:left_app_id],
  #             left_app_event_id:      app_config[:left_app_event_id],
  #             level:                  app_config[:level],
  #             config:                 app_config[:config],
  #             sequence_id:            sequence
  #           })
  #           unless konnect_activity.valid?
  #             raise "Something went wrong while connecting app #{app.name}."
  #           else
  #             konnect_activities << konnect_activity
  #           end
  #         else
  #           raise "Right side app #{app.name} event is not valid."
  #         end
  #         sequence += 1
  #       end
  #       KonnectUiInformation.create({
  #         konnect: konnect,
  #         data: params[:canvas_json]
  #       })
  #     else
  #       raise "right_apps should be an array and should have atleast one app."
  #     end
  #             enable_webhook(konnect, user, left_app_user, left_app_event, params)# if !left_app.webhook_enabled
  #           rescue Exception => e
  #             konnect_activities.each do |kc|
  #               kc.destroy if kc.try(:id).present?
  #             end
  #             konnect_webhook.destroy if konnect.try(:konnect_webhook).present?
  #             konnect.destroy if konnect.try(:id).present?
  #             return {error: e.message}
  #           end
  #           {success: "Konnect added successfully"}
  #         end

  def enable_webhook
    begin
      konnect = self
      left_app_event = konnect.app_event
      app = left_app_event.app
      app_webhook_type = app.webhook_type
      left_app_user = konnect.app_user
      user = left_app_user.user

      if app.name == "RSS"
        begin
          service = "Services::Rss".constantize.new(app, user, left_app_user, konnect, nil, nil)
          service.schedule_fetch(true)
        rescue => exception
          Rails.logger.debug "::::: #{exception}"
        end
      elsif app.name == "Scheduler"
        begin
          service = "Services::Scheduler".constantize.new(app, user, left_app_user, konnect, nil, nil)
          service.schedule(true)
        rescue => exception
          Rails.logger.debug "::::: #{exception}"
        end
      else
        webhook = if app_webhook_type == App::APP_EVENT_LEVEL_WEBHOOK
            if left_app_event.webhook_type == AppEvent::EVENT_LEVEL_WEBHOOK
              Webhook.where(app_user: left_app_user, app_event: left_app_event).first
            elsif left_app_event.webhook_type == AppEvent::RESOURCE_LEVEL_WEBHOOK
              service = Services::GenericService.create_service(app, user, left_app_user, konnect, nil, nil)
              service.find_webhook(konnect.config)
            end
          elsif app_webhook_type == App::APP_LEVEL_WEBHOOK
            Webhook.where(app_user: left_app_user).first
          elsif app.app_type == "WEBHOOK" or app.app_type == "WEBHOOK_API"
            identifier = KonnectWebhook.where(konnect_id: konnect.id).last.try(:identifier)
            if konnect.webhook.nil?
              Webhook.create(app_user: left_app_user, app_event: left_app_event, identifier: identifier)
            else
              konnect.webhook.update(app_user: left_app_user, app_event: left_app_event, identifier: identifier)
              konnect.webhook
            end
          end
        Rails.logger.debug "::: konnect8989 #{konnect.inspect} :::: #{webhook && !(app.provider == "google_sheet" || app.provider == "google-form")}"
        if webhook && !(app.provider == "google_sheet" || app.provider == "google-form")
          konnect.webhook = webhook
          konnect.save
        else
          begin
            service = "Services::#{app.provider.gsub("-", "_").camelcase}".constantize.new(app, user, left_app_user, konnect, nil, nil)
            service.enable_webhook
          rescue => exception
            Rails.logger.debug "::::: #{exception}"
            raise "enable_webhook failed with error #{exception}"
          end
        end
        return true
      end
    rescue Exception => e
      raise "enable_webhook failed with error #{e}"
    end
  end

  def konnect_description
    begin
      if self.app_event.app.app_type == "WEBHOOK"
        desc = "Request on KonnectzIT webhook from " + self.app_event.app.name.to_s + " will trigger "
      else
        desc = self.app_event.name.to_s + " on " + self.app_event.app.name.to_s + " will trigger "
      end
      self.konnect_activities.order("id ASC").each do |ka|
        desc += ka.app_event.name.to_s + " on " + ka.app_event.app.name.to_s + ", "
      end
      desc = desc.chomp(", ") + "."
      return desc
    rescue Exception => e
      return ""
    end
  end

  def display_konnect_activities
    konnect_activities = []
    self.konnect_activities.order("id ASC").each do |k_a|
      konnect_activities << k_a if (k_a.try(:app_event) && (k_a.try(:app_event).try(:app).try(:app_type) != "ADD_ON" or k_a.try(:app_event).try(:app).name == "API"))
    end
    return konnect_activities
  end

  def delete_webhook
    unless soft_delete
      status_changes = self.saved_changes["status"]
      if status_changes && ["DELETED", "INACTIVE"].include?(status_changes[1]) && self.try(:app_event).try(:app).try(:webhook_type) != "App Level"
        webhook && webhook.remove_webhook
      end
    end
  end
end
