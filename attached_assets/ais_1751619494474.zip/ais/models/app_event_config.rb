# == Schema Information
#
# Table name: app_event_configs
#
#  id                  :bigint           not null, primary key
#  app_id              :integer          not null
#  app_event_id        :integer          not null
#  list_input_value    :string
#  list_display_value  :string
#  sequence            :integer
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#  config_key          :string
#  config_key_required :boolean          default(TRUE)
#  service_name        :string
#
class AppEventConfig < ApplicationRecord
    belongs_to :app_event
    belongs_to :app

    validates_presence_of :label, :config_key, :sequence, :side, :key_value_type
    validate :check_list_type_fields_present

    before_validation :ensure_list_type_values

    SIDES = [ "left", "right" ]
    TYPES = [ "input", "text", "list" ]

    scope :config_attributes, -> { where(sequence: 0) }

    def self.ransackable_attributes(auth_object = nil)
        ["app_event_id", "app_id", "config_key", "config_key_required", "created_at", "fetch_fields", "id", "key_value_type", "label", "sequence", "service_name", "side", "updated_at"]
    end

    private

    def check_list_type_fields_present
        if key_value_type == "list"
            errors.add(:service_name, "can't be blank") if service_name.blank?
        end
    end

    def ensure_list_type_values
        if key_value_type != "list"
            service_name = nil
        end
    end

end
