
class Services::Rebrandly < Services::GenericService

    def authorize(params)
        create_app_user(params)
    end

    def auth_url(request)
        {fields: [{id: 'apikey', name: 'API KEY', instructions: [ "Login to your Rebrandly account", "Goto API option in right corner below your profile pic", "Click on New API Key <a href='https://app.rebrandly.com/account/api' target='_blank'> refer this link </a>" ]}]}
    end

    #################################################################################################
    # Webhook receive
    #################################################################################################

    def process_webhook(data, test = false)
        # event_type = konnect_activity.app_event.name.downcase
        # case event_type
        # when 'create branded link'
        #     create_branded_link(data)
        # when 'update branded link'
        #     update_branded_link(data)
        # end
        event_type = konnect_activity.app_event.name.downcase
        method_name = event_type.split(' ').join('_')
        send(method_name, data, test)
    end

    def create_branded_link(params, test)   
        begin 
            apikey = app_user.auth_details["apikey"]            
            response = HTTParty.post("https://api.rebrandly.com/v1/links", {
                :body => { 
                    "title" => params["title"],
                    "slashtag" => params["slashtag"],
                    "destination" => params["destination"]                     
                }.to_json,
                :headers => { 
                    "apikey" => apikey,
                    "Content-Type" => "application/json"                
                }
            })
            Rails.logger.debug "#{response.inspect}"
            if test
                ret = []
                if response.include?('errors') || response.include?('error') || response.has_value?('InvalidFormat')

                    ret << [ response, 'Failure']             
                else
                    ret << [response, 'Success']                 
                end
                ret.flatten
            end
        rescue  => e
            Rails.logger.debug "In Rescue"
        end       
    end

    #def update_branded_link(params)
    #   begin
    #        apikey = app_user.auth_details["apikey"]       
    #        puts params[:id].inspect
    #        puts params[:title].inspect    
    #
    #        response = HTTParty.post("https://api.rebrandly.com/v1/links/"+params[:id].to_s, {
    #            :body => { 
    #                "title" => params["title"],
    #                "slashtag" => params["slashtag"],
    #                "destination" => params["destination"]                     
    #            }.to_json,
    #            :headers => { 
    #                "apikey" => apikey,
    #                "Content-Type" => "application/json"
    #            }
    #        })
    #        puts response.body 
    #    rescue  => e
    #    end        
    #end

    #def get_link_details(params)
    #    begin
    #        apikey = app_user.auth_details["apikey"]       
    #        headers = {"apikey" => apikey, "Content-Type" => "application/json" }         
    #
    #        response = HTTParty.get("https://api.rebrandly.com/v1/links/"+params["id"].to_s, :headers => headers)
    #
    #        puts response.body
    #    rescue  => e
    #    end       
    #end

    def fetch_config_errors(error_response, app_event)
        generic_error = true
        app_configs = app_event.app_event_configs.where(side: 'right', sequence: 0).select("config_key").collect{|a| a.config_key}
        parsed_errors = {}
        if error_response['errors'] and !error_response['errors'].empty?
            error_response['errors'].each do |error|
                if app_configs.include?(error['property'])
                    parsed_errors = parsed_errors.merge!({"#{error['property']}": {message: error['message']}})
                    generic_error = false
                end
            end
        else
            parsed_errors = {message: "Failed to send data to #{app_event.app.name}"}
        end
        return parsed_errors, generic_error
    end

end



