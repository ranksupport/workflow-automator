# == Schema Information
#
# Table name: app_events
#
#  id          :bigint           not null, primary key
#  name        :string
#  description :text
#  app_id      :integer
#  side        :string
#  event_hook  :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
class AppEvent < ApplicationRecord

  belongs_to :app
  has_many :app_event_configs, dependent: :destroy
  has_many :event_config_attributes, -> { config_attributes }, class_name: "AppEventConfig", foreign_key: 'app_event_id'

  SIDES = ['left', 'right']
  EVENT_LEVEL_WEBHOOK = 'App Event Level'
  RESOURCE_LEVEL_WEBHOOK = 'Resource Level'
  WEBHOOK_TYPES = [EVENT_LEVEL_WEBHOOK, RESOURCE_LEVEL_WEBHOOK]

  def fetch_config_values(raw_response, test_status, side)
    @configs = self.app_event_configs.where(side: side, sequence: 0)
    config_values = {}
    if test_status == 'Success'
      @configs.collect do |config|
        config_values = config_values.merge!("#{config.config_key}": raw_response[config.config_key])
      end
    end
    if config_values.empty?
       config_values = raw_response
    end 
    config_values.to_json
  end


  def name_symbolized
    name.downcase.squish.tr(' ', '_').to_sym
  end

  def self.ransackable_attributes(auth_object = nil)
    ["app_id", "created_at", "description", "event_hook", "event_names", "id", "name", "side", "updated_at", "webhook_type"]
  end
end
