# == Schema Information
#
# Table name: apps
#
#  id                :bigint           not null, primary key
#  name              :string
#  description       :text
#  auth_type         :string
#  side              :string
#  authorization_url :string
#  created_at        :datetime         not null
#  updated_at        :datetime         not null
#  app_client_key    :string
#  app_secret        :string
#
# app_type: ADD_ON | WEBHOOK | WEBHOOK_API | API

class App < ApplicationRecord
    has_many :app_events
    has_many :app_event_configs
    has_many :app_users
    has_many :apps, through: :app_users
    has_many :tasks

    has_attached_file :image

    def self.ransackable_associations(auth_object = nil)
        ["app_event_configs", "app_events", "app_users", "apps", "tasks"]
    end

    def self.ransackable_attributes(auth_object = nil)
 	["app_client_key", "app_secret", "app_type", "auth_type", "authorization_url", "background_color", "category_tags", "created_at", "description", "id", "image_content_type", "image_file_name", "image_file_size", "image_updated_at", "name", "provider", "service_name", "side", "status", "updated_at", "webhook_enabled", "webhook_instructions", "webhook_type"]
    end

    # Validate the attached image is image/jpg, image/png, etc
    validates_attachment_content_type :image, :content_type => /\Aimage\/.*\Z/
    validates :provider, uniqueness: true

    OMNIAUTH = 'Omniauth'
    TOKEN = 'Token'
    AUTH_TYPES = [ OMNIAUTH, TOKEN ]
    SIDES = ['Left', 'Right', 'Both']
    APP_STATUS = ['Beta', 'Live']

    APP_LEVEL_WEBHOOK = 'App Level'
    APP_EVENT_LEVEL_WEBHOOK = 'App Event Level'
    WEBHOOK_URL_WEBHOOK = 'Webhook Url'
    HYBRID = 'Hybrid'

    WEBHOOK_TYPES = [APP_LEVEL_WEBHOOK, APP_EVENT_LEVEL_WEBHOOK, WEBHOOK_URL_WEBHOOK, HYBRID]

    after_initialize :set_bg_color

    APP_TYPES = ['ADD_ON', 'WEBHOOK', "WEBHOOK_API", "API"]

    APP_TYPES.each do |m|
        define_method(:"is_#{m.downcase}?") do
            app_type == m
        end
    end

    def image_url
        image.try(:url)
    end

    def self.generate_webhook_url(current_user)
        KONNECT_WEBHOOK_URL+SecureRandom.alphanumeric(10).to_s+'-kz'+current_user.id.to_s+'-'+SecureRandom.alphanumeric(10).to_s
    end

    def as_json(options={})
        super(
            :only => [:name],
            :include => { 
                :app_events => {
                    :only => [:name, :description, :side, :event_names, :webhook_type],
                    :include => {
                        :app_event_configs => {
                            :only => [:sequence, :config_key, :config_key_required, :service_name, :side, :key_value_type, :label, :fetch_fields]
                        }
                    }
                }
            }
        )
    end
    
    private
    def set_bg_color
        self.background_color = "#e9f7ec" unless self.background_color.present?
        self.webhook_enabled = false unless self.webhook_enabled
    end
end
