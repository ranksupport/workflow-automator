Rails.application.routes.draw do
  devise_for :admin_users, ActiveAdmin::Devise.config
  mount Rswag::Ui::Engine => "/api-docs"
  mount Rswag::Api::Engine => "/api-docs"
  ActiveAdmin.routes(self)

  namespace :api do
    namespace :v1 do
      resources :products, only: [:index, :show, :create, :update, :destroy]
      resources :apps, only: [:index] do
        member do
          get "authorized_app_accounts"
        end
        collection do
          get "authorized_apps"
          get "index1"
          get "authorized_apps1"
          get "public_app_list"
          get "add_on_apps"

          get "get_triggers"
          get "get_actions"
          get "get_allapps"

        end

        resources :app_events, only: [:index] do
          get "event_config/:side" => "app_event_configs#event_config"
          get "event_config/:side/:config_id/details" => "app_event_configs#event_config_details"
          get "event_config/:side/:config_id/fetch-fields" => "app_event_configs#fetch_fields"
        end
      end

      resources :task_logs, only: [:list, :tasks, :konnects, :logs] do
        collection do
          get "list"
          get "konnects"
          get "logs"
        end
        member do
          get "tasks"
          get "retry"
        end
      end

      resources :konnects, only: [:index, :edit] do
        member do
          post "update_konnect"
          post "update_status"
          post "place_webhook_activity"
          post "duplicate"
        end
        collection do
          post "test_and_review"
          post "left_app_trigger_test_event"
          post "save_konnect"
          post "publish_konnect"
          post "delete_activity"
          get "conditions_list"
        end
      end

      resources :app_users do
        member do
          post "update_status"
          post "update_label"
        end
      end

      resources :products do
        collection do
          get "list"
          get "redeemed_coupons"
          post "redeem_coupon"
        end
      end

      resources :folders do
        member do
          get "konnects"
          post "assign"
          get "remove"
          put "rename"
        end
        collection do
          get "list"
          post "add"
        end
      end

      get "widgets/active" => "widgets#active"
      get "widgets/details/:widget_key" => "widgets#details"
      post "auth-url" => "app_authorizations#auth_url"
      post "authorization" => "app_authorizations#authorization"
      post "connect" => "konnects#connect"

      devise_for :users
      post "auth/login", to: "authentication#authenticate"
      post "signup", to: "users#create"
      post "users/email_confirmation", to: "users#email_confirmation"
      post "users/reset_password_email", to: "users#reset_password_email"
      post "users/update_user", to: "users#update_user"
      post "users/update_user_password", to: "users#update_user_password"
      post "users/user_exists", to: "users#user_exists"
      match "users/profile", to: "users#profile", via: [:get, :post]
      post "users/change_password", to: "users#change_password"
      post "konnect_webhooks/capture_webhook_response/:identifier", to: "konnect_webhooks#capture_webhook_response"
      get "users/list_team_users", to: "users#list_team_users"
      post "users/add_team_user", to: "users#add_team_user"
      post "users/update_team_user", to: "users#update_team_user"
      get "users/remove_team_user", to: "users#remove_team_user"
      get "users/list_agency_users", to: "users#list_agency_users"
      post "users/add_agency_user", to: "users#add_agency_user"
      get "users/remove_agency_user", to: "users#remove_agency_user"
      post "users/update_agency_user", to: "users#update_agency_user"

      get "users/list_reseller_users", to: "users#list_reseller_users"
      post "users/add_reseller_user", to: "users#add_reseller_user"
      get "users/remove_reseller_user", to: "users#remove_reseller_user"
      post "users/update_reseller_user", to: "users#update_reseller_user"

      get "apps/:app_identifier" => "apps#public_events", constraints: { app_identifier: /[^\/]+/ }
      get "send_confirmation_email" => "users#send_confirmation_email"
      post "capture_user_persona" => "users#capture_user_persona"
      post "linkage/python", to: "linkage#python_linkage"
      get ":short_id" => "shorten_urls#index"
    end
  end

  get "/webhooks/:provider/receive", to: "api/v1/konnects#webhook_complete"
  post "/webhooks/:provider/receive", to: "api/v1/konnects#webhook_receive"
  get "/webhooks/:provider/get_receive", to: "api/v1/konnects#webhook_receive"
  get "/:provider/callback" => "api/v1/app_authorizations#authenticate"
  post "/webhooks/google_forms/receive" => "api/v1/konnects#webhook_receive"
  post "/auth/:provider/authenticate" => "api/v1/app_authorizations#authenticate"
  match "/webhooks/catch/:identifier", to: "api/v1/konnect_webhooks#catch", via: [:get, :post]
  match "/catch/:identifier", to: "api/v1/konnect_webhooks#catch", via: [:get, :post]
  match "/funnel_webhooks/test", to: "api/v1/konnect_webhooks#funnel_webhooks_test", via: [:get, :post]
  post "/webhooks/billing/:source", to: "api/v1/konnect_webhooks#billing"
  match "/webhooks/thrivecart_checkout", to: "api/v1/webhooks#thrivecart_checkout", via: [:head, :post]

  root to: "admin/dashboard#index"
end
